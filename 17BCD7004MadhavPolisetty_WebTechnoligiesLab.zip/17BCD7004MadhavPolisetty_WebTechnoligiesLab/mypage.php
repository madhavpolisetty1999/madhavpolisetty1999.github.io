<?php
echo $_POST['abc'];
echo '<br>';
  echo $_POST['xyz'];
?>
