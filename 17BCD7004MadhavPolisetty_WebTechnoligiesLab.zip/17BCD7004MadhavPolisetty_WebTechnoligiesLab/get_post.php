<!DOCTYPE html>
<html>
	<head>
		<title>My Website</title>
	</head>
<body>
	<form method="POST" action="mypage.php">
		<div>
			<label>Name</label><br>
			<input type="text" name="xyz" required>
		</div>
		<div>
			<label>Email</label><br>
			<input type="text" name="abc" required>
		</div>	
		<input type="submit" value="Submit">
	</form>
</body>
</html>
